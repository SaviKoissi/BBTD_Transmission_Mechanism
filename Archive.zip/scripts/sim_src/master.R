# ==========================================================
# RUN THE SIMMULATION
# ==========================================================

config <- yaml::read_yaml("scripts/sim_src/Phase1/config/config.yml")

source("scripts/Obs_process/run.R") # This script will run all the analyses related to the data

source("scripts/sim_src/Phase1/spatial_embedding.R")
source("scripts/sim_src/Phase1/distance_matrix.R")
source("scripts/sim_src/Phase1/network_adjacency.R")
source("scripts/sim_src/Phase1/initial_state.R")
source("scripts/sim_src/Phase1/observed_metrics.R")
source('scripts/sim_src/Phase1/build_phase1.R')
source("scripts/sim_src/Phase1/phase1.R")

source("scripts/sim_src/Phase2/prior.R")
source("scripts/sim_src/Phase2/sampling.R")
source("scripts/sim_src/Phase2/transformation.R")
source("scripts/sim_src/Phase2/particules.R")
source("scripts/sim_src/Phase2/init_simulation.R")
source("scripts/sim_src/Phase2/run_phase2.R")
source("scripts/sim_src/Phase2/ph2_exe.R")

source("scripts/sim_src/Phase3/normalization.R")
source("scripts/sim_src/Phase3/kernels.R")
source("scripts/sim_src/Phase3/infection_pressure.R") # Load this AFTER kernels
source("scripts/sim_src/Phase3/bias_injection.R")
source("scripts/sim_src/Phase3/simulation_engine.R")
source("scripts/sim_src/Phase3/abc_particle_run.R")
source("scripts/sim_src/Phase3/run_phase3.R")
source("scripts/sim_src/Phase3/phase3.R")

source("scripts/sim_src/Phase4/misclassification.R")
source("scripts/sim_src/Phase4/wavefront_velocity.R")
source("scripts/sim_src/Phase4/clustering_stats.R")
source("scripts/sim_src/Phase4/prevalence_stats.R")
source("scripts/sim_src/Phase4/summary_stats.R")
source("scripts/sim_src/Phase4/run_phase4.R")
source("scripts/sim_src/Phase4/phase4.R")

source("scripts/sim_src/Phase5/distance.R")
source("scripts/sim_src/Phase5/acceptance.R")
source("scripts/sim_src/Phase5/weighting.R")
source("scripts/sim_src/Phase5/resampling.R")
source("scripts/sim_src/Phase5/posterior/extract_posterior.R")
source("scripts/sim_src/Phase5/posterior/summary_tables.R")
source("scripts/sim_src/Phase5/posterior/ternary_plot.R")
source("scripts/sim_src/Phase5/posterior/posterior_plots.R")
source("scripts/sim_src/Phase5/posterior/model_comparison.R")
source("scripts/sim_src/Phase5/diagnostics.R")
source("scripts/sim_src/Phase5/run_phase5.R")
source("scripts/sim_src/Phase5/phase5.R")

source("scripts/sim_src/Phase6/run_phase6.R")
source("scripts/sim_src/Phase6/phase6.R")
